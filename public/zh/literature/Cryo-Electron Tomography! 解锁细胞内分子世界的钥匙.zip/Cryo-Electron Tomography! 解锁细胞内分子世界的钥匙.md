#### 一、引子：我们为何需要Cryo-ET？

传统结构生物学依赖于"分而治之"（divide and conquer）策略，通过X射线晶体学、核磁共振（NMR）光谱和单颗粒冷冻电镜（cryo-EM SPA）等方法，在原子分辨率下解析了数以千计的蛋白质结构。这些技术为蛋白质结构数据库（如PDB）奠定了坚实的基础。

然而，细胞内蛋白质的功能并不是孤立发挥的，而是依赖于它们之间复杂且动态的相互作用。在细胞这一高度拥挤的环境中，蛋白质之间可能以短暂或稳定的方式结合，形成分子网络，共同调控生理活动。作者Cryo-ET领域的大牛Wolfgang Baumeister引用David Goodsell的水彩画（下图）来形容细胞内环境的“拥挤与复杂”，指出我们迫切需要一种能够原位、完整地观察细胞分子景观的方法。

![](images/image-9.png)

![](images/image-8.png)

Cryo-ET（冷冻电子断层扫描）为解决这一挑战提供了突破口。它不仅能以接近生命自然状态的方式保持细胞结构，还能在无需荧光标签的前提下提供全面、真实的三维图像。这意味着研究者可以在不带偏见的前提下“看到全部”，观察预期与非预期的细胞结构。

***

#### 二、什么是Cryo-Electron Tomography？

Cryo-ET 是“电子断层扫描”（electron tomography）与“冷冻电镜”（cryo-EM）技术的结合。它的核心原理是将细胞或组织快速冷冻到液氮温度（避免水结晶），然后在电子显微镜中从多个角度对其进行成像，再利用计算算法重建出三维图像。



> "Cryo-ET provides holistic views of the inner space of cells and therefore has huge discovery potential."
> ——Cryo-ET 能够以整体视角描绘细胞内部空间，具有巨大的发现潜力。



与荧光显微镜相比，它不依赖预设标签，因此不受先验假设的限制；与单颗粒冷冻电镜不同，它不要求分子是重复、可平均的粒子，而能解析复杂、多样、非对称的细胞场景。

![](images/image-4.png)

![](images/image-3.png)



***

#### 三、Cryo-ET 的技术发展历程

早在30年前，研究人员就证明通过自动化倾斜数据采集，可以将电子束对样本的辐射剂量控制在可接受范围内，使得对冰包埋的生物样本成像成为可能（Dierksen et al., 1993）。

但最初Cryo-ET只能用于病毒或细菌等小而薄的样本，因为电子束无法穿透较厚的真核细胞。真核细胞只有靠近边缘的部位，如细胞膜、突起等，才能被观察。

转机出现在FIB（Focused Ion Beam）技术被引入后。研究者可用离子束将厚样本局部研磨至电子透明厚度，形象地说是“在细胞上打开窗口”。这项技术极大拓宽了Cryo-ET的应用范围。

尽管如此，整个实验流程——包括冷冻、研磨、转移、成像、重建与分析——仍然十分繁琐、效率有限。作者指出：“workflow ... is long and often cumbersome”（整个流程漫长且常常繁重）。因此，Cryo-ET虽前景光明，但其实现仍需多方面技术革新。

![](images/image-1.png)

***

#### 四、Cryo-ET 的完整工作流程

Cryo-ET 包含以下关键步骤：

1. **冷冻固定（Vitrification）**：将样本以极快速度冷却，形成非晶态冰，防止冰晶破坏结构。小样本采用液氮冲淬（plunge freezing），大体积样本如组织则需高压冷冻（high-pressure freezing）。

2. **薄层制备（FIB Milling）**：由于细胞厚度不适合电子束透射，需使用离子束切割出100-200纳米厚的lamellae。此步骤耗时且效率低，是瓶颈之一。

3. **定位目标区域（Cryo-CLEM）**：结合冷冻荧光显微镜（Cryo-correlative light electron microscopy），通过荧光标记帮助定位特定结构，如线粒体、内质网或病理聚集体。

4. **倾斜成像（Tilt series acquisition）**：在电子显微镜中对样本从不同角度拍摄（通常每2度一个角度，共收集约100张投影图）。

5. **三维重建（Tomogram reconstruction）**：通过重建算法（如SIRT、WBP等）生成三维体积图像。

6. **后续分析**：图像增强、去噪、识别结构、平均处理等，通常依赖AI算法和数据库比对完成。

![](images/image-6.png)

***

#### 五、技术瓶颈与潜在改进

作者特别指出FIB研磨是当前Cryo-ET实验中的“瓶颈工序”。尽管自动化有所进展，但制备一张lamella仍需数小时，限制了大规模实验的通量。

未来改进方向包括：

* 使用等离子源（如氦、氖）替代传统的镓离子束，提高研磨速度与精准度；

* 开发高速相机与样品台，实现秒级数据采集（目前每套倾斜序列约需20-40分钟）；

* 推动Cryo-CLEM系统一体化设计，减少光学定位与电子切割之间的误差与污染

![](images/image-7.png)



***

#### 六、图像质量提升与深度学习应用

由于需保护样本不被电子束破坏，Cryo-ET成像剂量非常低，导致图像信号弱、噪声大。为此，研究者引入“相位板”（phase plate）提升成像对比度。Volta相位板（VPP）目前使用广泛，尤其适合检测小分子、可变结构。

![](images/image-2.png)

原文提到：

> Usage of the Volta phase plate has proven useful for the detection of small and variable structures in crowded cellular environments.”



此外，深度学习工具（如Warp、Noise2Noise）可用于图像增强与去噪，显著提升图像质量与可解释性。未来的“激光相位板”或可在提升对比度的同时，避免VPP存在的稳定性与寿命问题。

***

#### 七、分子识别与结构解析方法

Cryo-ET 获得的三维数据通常包含大量未知密度，需要进一步识别。作者总结了以下两种主流方法：

1. **模板匹配法（Template matching）**：将已知结构（如AlphaFold预测的蛋白质模型）与图像密度进行匹配，从而识别出特定分子。

2. **无模板方法（Template-free, ML-based）**：利用机器学习在图像中寻找“潜在目标”，对未知结构更具探索性。

Subtomogram Averaging 是提高图像分辨率的有效手段。它通过对同种分子进行对齐与平均处理，可提升信噪比并观察其不同构象。当前分辨率可达亚纳米级，尤其是对高丰度粒子如核糖体（ribosome）和表达体（expressome）。

![](images/image.png)

***

#### 八、应用实例：从基因表达到神经疾病

作者引用了两个代表性研究案例：

1. **表达体结构**：研究者观察到细菌中转录与翻译之间的直接耦合结构——DNA、RNA聚合酶、核糖体通过蛋白质NusA构成一个连续操作链（expressome），首次在活细胞中可视化了基因表达的整个流程。

2. **神经疾病蛋白聚集**：Cryo-ET 揭示PolyQ与Poly-GA两种神经退行性疾病相关蛋白的结构差异：前者与内质网膜结构发生作用导致破裂，后者聚集阻碍蛋白酶体，提示了不同的毒性机制。

![](images/image-5.png)

这些例子表明，Cryo-ET 不仅是结构工具，更是一种揭示生命过程的观察手段。

***

#### 九、未来展望与挑战

尽管Cryo-ET已取得重大进展，但作者指出仍存在如下挑战：

* **低丰度分子的识别困难**；

* **小分子与非蛋白结构难以分辨**；

* **标记方法不足**：目前缺乏可靠的冷冻条件下可识别的分子标签；

* **数据注释不足**：Tomogram 中大部分密度仍未被识别。

为此，作者建议融合其他方法（如光学标记、质谱交联、机器学习）以实现多维度解析。同时，也呼吁制定一套衡量tomogram信息密度和分辨率的新标准。



作者总结：

> “Cryo-ET has unique potential to generate molecular maps of cellular landscapes... That is where many see the future of structural biology.”



Cryo-ET 不仅让我们看到了细胞结构，更将揭示细胞活动的动态全景图，代表着结构生物学发展的下一个十年方向。



***

原文链接：https://doi.org/10.1016/j.cell.2022.06.034
